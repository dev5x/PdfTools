﻿using System;
using System.Text;
using System.IO;
using iText.Kernel.Pdf;

namespace dev5x.PdfTools
{
    public class Encrypt
    {
        public event EventHandler ErrorMessage;

        private void SetErrorMessage(string msg)
        {
            ErrorMessage?.Invoke(msg, EventArgs.Empty);
        }

        #region Public Methods
 
        public bool EncryptFile(string OriginalFileName)
        {
            try
            {
                string encryptedFileName = Path.Combine(Path.GetDirectoryName(OriginalFileName), Path.GetFileNameWithoutExtension(OriginalFileName) + "_encrypt.pdf");
                byte[] pwd = Encoding.ASCII.GetBytes("");

                WriterProperties writerProp = new WriterProperties();
                int encryptOptions = EncryptionConstants.ALLOW_PRINTING | EncryptionConstants.ALLOW_SCREENREADERS | EncryptionConstants.ALLOW_FILL_IN;
                writerProp.SetStandardEncryption(pwd, pwd, encryptOptions, EncryptionConstants.STANDARD_ENCRYPTION_128);

                using (PdfWriter encryptedWriter = new PdfWriter(encryptedFileName, writerProp))
                using (PdfDocument encryptedDocument = new PdfDocument(encryptedWriter))
                using (PdfDocument pdfDocOriginal = new PdfDocument(new PdfReader(OriginalFileName)))
                {
                    pdfDocOriginal.CopyPagesTo(1, pdfDocOriginal.GetNumberOfPages(), encryptedDocument);
                }

                // Delete original file
                File.Delete(OriginalFileName);
                // Rename merged file to the original file
                File.Move(encryptedFileName, OriginalFileName);

                return true;
            }
            catch (Exception ex)
            {
                SetErrorMessage("EncryptFile - " + ex.Message);
                return false;
            }
        }
        #endregion
    }
}